<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Monitoring Peminjaman Mobil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f0f0f0;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .car-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }
        .car {
            width: 150px;
            height: 150px;
            margin: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .ready {
            background-color: red;
        }
        .booked {
            background-color: yellow;
            color: black;
        }
        .on_the_way {
            background-color: green;
        }
    </style>
</head>
<body>
    <h1>Sistem Monitoring Peminjaman Mobil</h1>
    <div class="car-container">
        <div class="car ready" onclick="ubahStatus(this)">Mobil 1</div>
        <div class="car booked" onclick="ubahStatus(this)">Mobil 2</div>
        <div class="car on_the_way" onclick="ubahStatus(this)">Mobil 3</div>
        <div class="car ready" onclick="ubahStatus(this)">Mobil 4</div>
        <div class="car on_the_way" onclick="ubahStatus(this)">Mobil 5</div>
    </div>

    <script>
        function ubahStatus(elemen) {
            if (elemen.classList.contains('ready')) {
                elemen.classList.remove('ready');
                elemen.classList.add('booked');
                elemen.textContent = elemen.textContent + " - Di-booking";
            } else if (elemen.classList.contains('booked')) {
                elemen.classList.remove('booked');
                elemen.classList.add('on_the_way');
                elemen.textContent = elemen.textContent.split(" - ")[0] + " - Dalam Perjalanan";
            } else if (elemen.classList.contains('on_the_way')) {
                elemen.classList.remove('on_the_way');
                elemen.classList.add('ready');
                elemen.textContent = elemen.textContent.split(" - ")[0];
            }
        }
    </script>
</body>
</html>
